﻿Public Class StartUp
    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        mainform.Show()
        Me.Hide()
    End Sub
End Class

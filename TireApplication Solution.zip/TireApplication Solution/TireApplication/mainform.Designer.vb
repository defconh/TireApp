﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.IntentoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BrandToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PriceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TireTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerformanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecappedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OfficeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MiscToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DescriptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HoursToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JobTitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonthToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeekToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IncomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpensesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IntentoryToolStripMenuItem, Me.SuppliesToolStripMenuItem, Me.EmployeesToolStripMenuItem, Me.SalesToolStripMenuItem, Me.IEToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(463, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'IntentoryToolStripMenuItem
        '
        Me.IntentoryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BrandToolStripMenuItem, Me.PriceToolStripMenuItem, Me.TireTypeToolStripMenuItem, Me.PerformanceToolStripMenuItem, Me.SizeToolStripMenuItem, Me.RecappedToolStripMenuItem})
        Me.IntentoryToolStripMenuItem.Name = "IntentoryToolStripMenuItem"
        Me.IntentoryToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.IntentoryToolStripMenuItem.Text = "&Intentory"
        '
        'SuppliesToolStripMenuItem
        '
        Me.SuppliesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OfficeToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.MiscToolStripMenuItem})
        Me.SuppliesToolStripMenuItem.Name = "SuppliesToolStripMenuItem"
        Me.SuppliesToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.SuppliesToolStripMenuItem.Text = "&Supplies"
        '
        'EmployeesToolStripMenuItem
        '
        Me.EmployeesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DescriptionToolStripMenuItem, Me.HoursToolStripMenuItem, Me.JobTitleToolStripMenuItem})
        Me.EmployeesToolStripMenuItem.Name = "EmployeesToolStripMenuItem"
        Me.EmployeesToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.EmployeesToolStripMenuItem.Text = "&Employees"
        '
        'SalesToolStripMenuItem
        '
        Me.SalesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MonthToolStripMenuItem, Me.WeekToolStripMenuItem, Me.DayToolStripMenuItem})
        Me.SalesToolStripMenuItem.Name = "SalesToolStripMenuItem"
        Me.SalesToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
        Me.SalesToolStripMenuItem.Text = "&Sales"
        '
        'IEToolStripMenuItem
        '
        Me.IEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IncomeToolStripMenuItem, Me.ExpensesToolStripMenuItem, Me.DateToolStripMenuItem})
        Me.IEToolStripMenuItem.Name = "IEToolStripMenuItem"
        Me.IEToolStripMenuItem.Size = New System.Drawing.Size(33, 20)
        Me.IEToolStripMenuItem.Text = "I/E"
        '
        'BrandToolStripMenuItem
        '
        Me.BrandToolStripMenuItem.Name = "BrandToolStripMenuItem"
        Me.BrandToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BrandToolStripMenuItem.Text = "Brand"
        '
        'PriceToolStripMenuItem
        '
        Me.PriceToolStripMenuItem.Name = "PriceToolStripMenuItem"
        Me.PriceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PriceToolStripMenuItem.Text = "Price"
        '
        'TireTypeToolStripMenuItem
        '
        Me.TireTypeToolStripMenuItem.Name = "TireTypeToolStripMenuItem"
        Me.TireTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TireTypeToolStripMenuItem.Text = "Tire Type"
        '
        'PerformanceToolStripMenuItem
        '
        Me.PerformanceToolStripMenuItem.Name = "PerformanceToolStripMenuItem"
        Me.PerformanceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PerformanceToolStripMenuItem.Text = "Performance"
        '
        'SizeToolStripMenuItem
        '
        Me.SizeToolStripMenuItem.Name = "SizeToolStripMenuItem"
        Me.SizeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SizeToolStripMenuItem.Text = "Size"
        '
        'RecappedToolStripMenuItem
        '
        Me.RecappedToolStripMenuItem.Name = "RecappedToolStripMenuItem"
        Me.RecappedToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.RecappedToolStripMenuItem.Text = "Recapped?"
        '
        'OfficeToolStripMenuItem
        '
        Me.OfficeToolStripMenuItem.Name = "OfficeToolStripMenuItem"
        Me.OfficeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OfficeToolStripMenuItem.Text = "Office"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'MiscToolStripMenuItem
        '
        Me.MiscToolStripMenuItem.Name = "MiscToolStripMenuItem"
        Me.MiscToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MiscToolStripMenuItem.Text = "Misc"
        '
        'DescriptionToolStripMenuItem
        '
        Me.DescriptionToolStripMenuItem.Name = "DescriptionToolStripMenuItem"
        Me.DescriptionToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DescriptionToolStripMenuItem.Text = "Description"
        '
        'HoursToolStripMenuItem
        '
        Me.HoursToolStripMenuItem.Name = "HoursToolStripMenuItem"
        Me.HoursToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HoursToolStripMenuItem.Text = "Hours"
        '
        'JobTitleToolStripMenuItem
        '
        Me.JobTitleToolStripMenuItem.Name = "JobTitleToolStripMenuItem"
        Me.JobTitleToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.JobTitleToolStripMenuItem.Text = "Job Title"
        '
        'MonthToolStripMenuItem
        '
        Me.MonthToolStripMenuItem.Name = "MonthToolStripMenuItem"
        Me.MonthToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MonthToolStripMenuItem.Text = "Month"
        '
        'WeekToolStripMenuItem
        '
        Me.WeekToolStripMenuItem.Name = "WeekToolStripMenuItem"
        Me.WeekToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.WeekToolStripMenuItem.Text = "Week"
        '
        'DayToolStripMenuItem
        '
        Me.DayToolStripMenuItem.Name = "DayToolStripMenuItem"
        Me.DayToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DayToolStripMenuItem.Text = "Day"
        '
        'IncomeToolStripMenuItem
        '
        Me.IncomeToolStripMenuItem.Name = "IncomeToolStripMenuItem"
        Me.IncomeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.IncomeToolStripMenuItem.Text = "Income"
        '
        'ExpensesToolStripMenuItem
        '
        Me.ExpensesToolStripMenuItem.Name = "ExpensesToolStripMenuItem"
        Me.ExpensesToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExpensesToolStripMenuItem.Text = "Expenses"
        '
        'DateToolStripMenuItem
        '
        Me.DateToolStripMenuItem.Name = "DateToolStripMenuItem"
        Me.DateToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DateToolStripMenuItem.Text = "Date"
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.Font = New System.Drawing.Font("Modern No. 20", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogo.Location = New System.Drawing.Point(115, 105)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(200, 65)
        Me.lblLogo.TabIndex = 1
        Me.lblLogo.Text = "LOGO"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(388, 0)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "E&xit"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'mainform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(463, 255)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblLogo)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "mainform"
        Me.Text = "Tire Application"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents IntentoryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BrandToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PriceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TireTypeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerformanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecappedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SuppliesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OfficeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MiscToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EmployeesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DescriptionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HoursToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents JobTitleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MonthToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WeekToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IncomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExpensesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblLogo As Label
    Friend WithEvents btnClose As Button
End Class
